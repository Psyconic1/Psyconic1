from PIL import Image
from PIL import ImageFont
from PIL import ImageDraw
import tkinter as tk
from tkinter import filedialog
import cv2 as cv


def pathfinder(path):
    a=''
    for i in path:
        if i==',':
            break
        elif i=='(':
            pass
        else:
            a=a+i
    return a


# image opening
root=tk.Tk()
root.withdraw()
water_path=filedialog.askopenfilenames(title=('Select The Image to be Watermarked'))
waterpatha=pathfinder(water_path)



image = Image.open(waterpatha)
w, h = image.size
watermark_image = image.copy()
draw = ImageDraw.Draw(watermark_image)
x, y = int(w / 2), int(h / 2)
font = ImageFont.truetype("arial.ttf", 70)

draw.text((x+(x/2), y+(y/1.2)), "kali", fill=(3,8,12,25), font=font, anchor='ms')


watermark_image=watermark_image.save("newimage.jpg")

cv.imshow("newimage.jpg")
