#import libraries

import numpy as np
import cv2 as cv
import tkinter as tk
from tkinter import filedialog


root=tk.Tk()
root.withdraw()


#defining a function that corrects to corect file path
def pathfinder(path):
    a=''
    for i in path:
        if i==',':
            break
        elif i=='(':
            pass
        else:
            a=a+i
    return a
        
#defining a function that scales the image
def scale(image, scale_width):
    (image_height, image_width)=image.shape[:2]    #returns width and height
    new_height=int((scale_width/image_width)*image_height)
    
    return cv.resize(image, (scale_width,new_height))
def i(image, scale_width):
    (image_height, image_width)=image.shape[:2]    #returns width and height
    new_height=int((scale_width/image_width)*image_height)
    return scale_width,new_height

#import and resize watermarked image
water_path=filedialog.askopenfilenames(title=('Select The Image to be Watermarked'))
waterpatha=pathfinder(water_path)
watermark=cv.imread(waterpatha,cv.IMREAD_UNCHANGED)
watermark1=watermark
watermark=scale(watermark,150)
watermark=cv.cvtColor(watermark,cv.COLOR_BGR2BGRA)
watermark_width,watermark_hight=i(watermark1,150)    


#import and resize the original image
imagepath=filedialog.askopenfilenames(title=('Select The Original Image'))
imagepatha=pathfinder(imagepath)
image=cv.imread(imagepatha)
image1=image
(image_height,image_width)=image.shape[:2]
image=scale(image,1000)
image=cv.cvtColor(image,cv.COLOR_BGR2BGRA)
(image_width,image_height)=i(image1,1000)

#create an overlay image that contains the logo 


overlay=np.zeros((image_height,image_width,4),dtype='uint8')
overlay=scale(overlay,1000)
overlay[image_height-25-watermark_hight:image_height-25,image_width-25-watermark_width:image_width-25]=watermark



cv.addWeighted(overlay, 0.3,image, 1.0, 0.0, image) 


cv.imshow("Final image",image)

